<?php
return [
    'about' => 'A Propos',
    'criteria' => 'Critères D´investissement',
    'contact' => 'Nous Contacter',
    'team' => 'Équipe',
    'transaction' => 'Transaction',

];
