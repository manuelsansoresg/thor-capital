<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('vendor_assets/pagepiling/jquery.pagepiling.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor_assets/fontawesome/css/all.min.css')); ?>">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>

<body>
<?php

$classEsActive = (session('lang') == null) ? 'linkActive' : '';
$classEnActive = '';
$classFrActive = '';

if (session('lang') != null && session('lang') == 'es') {
    $classEsActive = 'linkActive';
}

if (session('lang') != null && session('lang') == 'en') {
    $classEnActive = 'linkActive';
}

if (session('lang') != null && session('lang') == 'fr') {
    $classFrActive = 'linkActive';
}
?>

    <div class="intro">
        
        <video  autoplay="autoplay" muted >
            <source src="<?php echo e(asset('video/TORCAPITAL.mp4')); ?>" type="video/mp4">

        </video>
    </div>




<nav class="navbar navbar-expand-lg navbar-light" style="display: none">
    <a class="navbar-brand" href="#">
        <img class="img-fluid" src="<?php echo e(asset('img/TorCapital.svg')); ?>" alt="">
    </a>
    <ul class="list-inline menu__lang-movil">
        <li class="list-inline-item <?php echo e($classEsActive); ?>"><a href="<?php echo e(url('lang', ['es'])); ?>">ES</a> </li>
        <li class="list-inline-item <?php echo e($classEnActive); ?>"><a href="<?php echo e(url('lang', ['en'])); ?>">EN</a> </li>
        <li class="list-inline-item <?php echo e($classFrActive); ?>"><a href="<?php echo e(url('lang', ['fr'])); ?>">FR</a> </li>
    </ul>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="#about" > <?php echo trans('menu.about'); ?> <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#investment-criteria"> <?php echo trans('menu.criteria'); ?></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="#the-team"> <?php echo trans('menu.team'); ?></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="#transactions"> <?php echo trans('menu.transaction'); ?></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="#contact"> <?php echo trans('menu.contact'); ?></a>
            </li>


        </ul>

    </div>
</nav>



    <div class="logo">
        <img class="img-fluid" src="<?php echo e(asset('img/TorCapital.svg')); ?>" alt="">
    </div>
    <div class="menu ">

        <ul class="list-inline menu__lang">
            <li class="">
                <a class="<?php echo e($classEsActive); ?>" href="<?php echo e(url('lang', ['es'])); ?>">
                    ES
                </a>
            </li>
            <li class="">
                <a class="<?php echo e($classEnActive); ?>" href="<?php echo e(url('lang', ['en'])); ?>">
                    EN
                </a>
            </li>
            <li class="">
                <a class="<?php echo e($classFrActive); ?>" href="<?php echo e(url('lang', ['fr'])); ?>">
                    FR
                </a>
            </li>
        </ul>
        <ul class="menu__nav list-inline d-none">
            <li>
                <a href="#about">
                    <?php echo trans('menu.about'); ?>

                </a>
            </li>
            <li>
                <a href="">
                    <a href="#contact" class="text-primary"> <?php echo trans('menu.contact'); ?></a>
                </a>
            </li>
            <li class="item list-inline-item">
                <a href="#investment-criteria"> <?php echo trans('menu.criteria'); ?></a>
            </li>

            <li class="item list-inline-item">
                <a href="#the-team"> <?php echo trans('menu.team'); ?></a>
            </li>

            <li class="item list-inline-item">
                <a href="#transactions"> <?php echo trans('menu.transaction'); ?></a>
            </li>

        </ul>
    </div>
    <?php echo $__env->yieldContent('content'); ?>
    <div class="footer">
        <ul class="list-inline">
            <li class="list-inline-item">
                <img class="footer__img" id="moveUp" src="<?php echo e(asset('img/Flechaarriba.svg')); ?>" alt="">
            </li>
            <li class="list-inline-item">
                <img class="footer__img" id="moveDown" src="<?php echo e(asset('img/Flechaabajo.svg')); ?>" alt="">
            </li>
        </ul>
    </div>
    <!-- Scripts -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
    <script src="<?php echo e(asset('vendor_assets/accordion/index.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor_assets/pagepiling/jquery.pagepiling.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\thor-capital\resources\views/layouts/app.blade.php ENDPATH**/ ?>