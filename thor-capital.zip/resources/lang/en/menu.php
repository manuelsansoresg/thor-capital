<?php
return [
    'about' => 'About Us',
    'criteria' => 'Investment <br> Criteria',
    'contact' => 'Contact Us',

];
