<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SectionLanguage extends Model
{
    protected $fillable = ['section_id', 'description'];
}
