<?php
return [
    'about' => 'Nosotros',
    'criteria' => 'Criterios <br> de Inversión',
    'contact' => 'Contactanos',

];
