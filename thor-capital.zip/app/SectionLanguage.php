<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SectionLanguage extends Model
{
    protected $fillable = ['section_id', 'description'];

    static function getAbout($lang)
    {
        $data = array();
        $title = SectionLanguage::where('section_id', 1)
                    ->where('lang', $lang)
                    ->where('name', 'title')
                    ->first();
       
        $description = SectionLanguage::where('section_id', 1)
                    ->where('lang', $lang)
                    ->where('name', 'description')
                    ->first();
        
        $description2 = SectionLanguage::where('section_id', 1)
                    ->where('lang', $lang)
                    ->where('name', 'description2')
                    ->first();


        return array('id' => $title->id, 'lang' => $title->lang ,  'title' => $title->description, 'description' => $description->description, 'description2' => $description2->description);
    }

    static function getAllAbout()
    {
        $data = array();
        $es   = SectionLanguage::getAbout('es');
        $en   = SectionLanguage::getAbout('en');
        $fr   = SectionLanguage::getAbout('fr');
        
        $data[] = ($es);
        $data[] = ($en);
        $data[] = ($fr);
        return $data;
    }

}
