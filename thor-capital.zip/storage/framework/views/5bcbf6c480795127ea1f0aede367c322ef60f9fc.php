<?php $__env->startSection('title', 'Nosotros'); ?>

<?php $__env->startSection('content_header'); ?>
<section class="content-header">
    <h1>
        Nosotros
        <small>Editar</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> Inicio</a></li>
        <li><a href="/admin/about"><i class="fa fa-dashboard"></i> Nosotros</a></li>
        <li class="active">Editar</li>
    </ol>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('vendor_assets/summernote/summernote.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
            $('#contenido').summernote(
                {
                    height: 200,
                    fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Campton-Medium', 'Campton-Light' , 'Campton-Book', 'Campton-ExtraBold', 'Campton-SemiBoldItalic'],
                    fontNamesIgnoreCheck: ["Campton-Medium", "Campton-Light", 'Campton-Book', 'Campton-ExtraBold', 'Campton-SemiBoldItalic']
                }
            );
        });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\thor-capital\resources\views/admin/about/edit.blade.php ENDPATH**/ ?>