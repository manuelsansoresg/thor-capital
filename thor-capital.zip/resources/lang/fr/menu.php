<?php
return [
    'about' => 'A Propos',
    'criteria' => 'Critères <br> D´investissement',
    'contact' => 'Nous Contacter',

];
