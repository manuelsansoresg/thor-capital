<?php
return [
    'about' => 'Nosotros',
    'criteria' => 'Criterios de Inversión',
    'contact' => 'Contáctanos',
    'team' => 'Equipo',
    'transaction' => 'Transacción',

];
