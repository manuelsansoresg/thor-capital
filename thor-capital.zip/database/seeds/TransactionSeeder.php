<?php

use App\SectionLanguage;
use Illuminate\Database\Seeder;

class TransactionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $findSection = SectionLanguage::where('section_id', 5);
        $findSection->delete();


        /* seccion1 ingles*/
        $section_language              = new SectionLanguage();
        $section_language->section_id  = 5;
        $section_language->name        = 'title';
        $section_language->lang        = 'en';
        $section_language->description = 'Transactions';
        $section_language->save();

        $section_language              = new SectionLanguage();
        $section_language->section_id  = 5;
        $section_language->name        = 'description';
        $section_language->lang        = 'en';
        $section_language->description = ' “My international colleagues bring me buyers that I know will increase the value for my client, even if the transaction is closed locally.” - Ruud van Hoek, Clairfield, Netherlands.';
;
        $section_language->save();
        /* ingles*/

        /* seccion1 ingles*/
        $section_language              = new SectionLanguage();
        $section_language->section_id  = 5;
        $section_language->name        = 'title';
        $section_language->lang        = 'fr';
        $section_language->description = 'Transactions';
        $section_language->save();

        $section_language              = new SectionLanguage();
        $section_language->section_id  = 5;
        $section_language->name        = 'description';
        $section_language->lang        = 'fr';
        $section_language->description = '“Mes associés internationaux apportent des acquéreurs qui optimiseront la valeur de mon client, même si la transaction se finalise localement.” Ruud van Hoek, Clairfield Netherlands.';
        ;
        $section_language->save();
        /* ingles*/

        /* seccion español*/
        $section_language              = new SectionLanguage();
        $section_language->section_id  = 5;
        $section_language->name        = 'title';
        $section_language->lang        = 'es';
        $section_language->description = 'Transacciones';
        $section_language->save();

        $section_language              = new SectionLanguage();
        $section_language->section_id  = 5;
        $section_language->name        = 'description';
        $section_language->lang        = 'es';
        $section_language->description = ' “Mis colegas internacionales traen compradores que sé que aumentarán el valor para mi cliente, incluso si la transacción se cierra localmente.” - Ruud van Hoek, Clairfield, Países Bajos.';
        $section_language->save();
        /* español*/
    }
}
